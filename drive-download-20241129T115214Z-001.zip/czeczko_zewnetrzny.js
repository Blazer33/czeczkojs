document.write("ostatnia modyfikacja strony".fontcolor("#808000").bold().strike().fontsize(5) + "<br>");
document.write(document.lastModified);
